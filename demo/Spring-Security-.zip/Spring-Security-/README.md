# Spring-Security
用来简单的验证spring security的权限信息，处理了登陆成功、失败、退出、认证不通过时的方式，以及不需要权限验证的路径的设置
